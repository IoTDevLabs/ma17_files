#include "new_thread0.h"
#include "FreeRTOS.h"
#include "FreeRTOS_sockets.h"
#include "FreeRTOS_IP.h"
#include "stdlib.h"
#include "stdio.h"
#include "eui_48.h"

#define HOSTNAME_BASE "ra_ekra6m3_g_"

#define HOSTNAME_UNIQUE EXPAND_TO_STRING(EUI_48_OCTET_4)  EXPAND_TO_STRING(EUI_48_OCTET_5)  EXPAND_TO_STRING(EUI_48_OCTET_6)


#define HOSTNAME HOSTNAME_BASE HOSTNAME_UNIQUE


const char * g_network_event[] =
{
     "Network UP", "Network DOWN"
};


const char *pcApplicationHostnameHook( void )
{
    return HOSTNAME;
}


void vApplicationIPNetworkEventHook( eIPCallbackEvent_t eNetworkEvent )
{
    printf("Network event = %s\r\n", g_network_event[eNetworkEvent]);

    if(eNetworkUp == eNetworkEvent)
    {
        uint32_t ulIPAddress, ulNetMask, ulGatewayAddress, ulDNSServerAddress;
        int8_t cBuffer[ 16 ];

        /* Signal application the network is UP */
        xSemaphoreGive( g_network_binary_semaphore);

        /* The network is up and configured.  Print out the configuration
        obtained from the DHCP server. */
        FreeRTOS_GetAddressConfiguration( &ulIPAddress,
                                          &ulNetMask,
                                          &ulGatewayAddress,
                                          &ulDNSServerAddress );

        /* Convert the IP address to a string then print it out. */
        FreeRTOS_inet_ntoa( ulIPAddress, cBuffer );
        printf( "IP Address:      %s\r\n", cBuffer );

        /* Convert the net mask to a string then print it out. */
        FreeRTOS_inet_ntoa( ulNetMask, cBuffer );
        printf( "Subnet Mask:  %s\r\n", cBuffer );

        /* Convert the IP address of the gateway to a string then print it out. */
        FreeRTOS_inet_ntoa( ulGatewayAddress, cBuffer );
        printf( "Gateway IP:     %s\r\n", cBuffer );

        /* Convert the IP address of the DNS server to a string then print it out. */
        FreeRTOS_inet_ntoa( ulDNSServerAddress, cBuffer );
        printf( "DNS server IP: %s\r\n", cBuffer );
    }
}

