
#ifndef __MEDIUM_ONE__H__
#define __MEDIUM_ONE__H__

/*
 * @brief MQTT Broker endpoint.
 *
 * @todo Set this to the fully-qualified DNS name of your MQTT broker.
 */
#define clientcredentialMQTT_BROKER_ENDPOINT         "mqtt.mediumone.com"

/*
 * @brief MQTT Broker username.
 *
 * @todo Set this to your Medium One MQTT username.
 */
#define clientcredentialMQTT_BROKER_USERNAME         "xxxxxxxxxxx/xxxxxxxxxxx"

/*
 * @brief MQTT Broker password.
 *
 * @todo Set this to your Medium One MQTT password.
 */
#define clientcredentialMQTT_BROKER_PASSWORD         "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx/xxxxxxxxxxxxxxxxx"

/*
 * @brief Port number the MQTT broker is using.
 */
#define clientcredentialMQTT_BROKER_PORT             61617		/* non-encrypted */

/*
 * @brief MQTT Publish topic.
 */
#define MQTT_TOPIC_PREFIX                            "x/xxxxxxxxxxx/xxxxxxxxxxx/xxxxxxxx"

#endif /* ifndef __MEDIUM_ONE__H__ */
