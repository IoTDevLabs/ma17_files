#include "hal_data.h"
#include "bsp_pin_cfg.h"
#include "usr_nmi_handler.h"
#include "r_ioport.h"

void R_BSP_WarmStart(bsp_warm_start_event_t event);
void  initialise_monitor_handles(void);


#define PRCR_KEY (0xa500UL)
#define PRC0_MASK (0x0001UL)

#define TRACE_CLOCK_DISABLE 0
#define TRACE_CLOCK_ENABLE  1
#define TRCK_1 0x00
#define TRCK_2 0x01
#define TRCK_4 0x02

#if defined (BOARD_RA6M3G_EK) || defined (BOARD_RA6M3_EK)
#define ETHER_PHY_RESET_PIN      BSP_IO_PORT_04_PIN_04

#define PHY_RESET_LEVEL          BSP_IO_LEVEL_LOW
#define PHY_ACTIVE_LEVEL         BSP_IO_LEVEL_HIGH

#define PHY_RESET_ACTIVE_TIMING  10 /* 10 ms */
#endif

void R_BSP_WarmStart(bsp_warm_start_event_t event);

/*******************************************************************************************************************//**
 * The RA Configuration tool generates main() and uses it to generate threads if an RTOS is used.  This function is
 * called by main() when no RTOS is used.
 **********************************************************************************************************************/
void hal_entry(void) {
	/* TODO: add your own code here */
}

/*******************************************************************************************************************//**
 * This function is called at various points during the startup process.  This implementation uses the event that is
 * called right before main() to set up the pins.
 *
 * @param[in]  event    Where at in the start up process the code is currently at
 **********************************************************************************************************************/
void R_BSP_WarmStart(bsp_warm_start_event_t event) {
    if (BSP_WARM_START_RESET == event)
    {
#if (BSP_CFG_MCU_PART_SERIES == 6)

        uint32_t prc0;
        /* C runtime environment has not been setup so you cannot use globals. System clocks and pins are not setup. */
        prc0 = R_SYSTEM->PRCR;
        /* Enable Register access */
        R_SYSTEM->PRCR = (uint16_t) ((R_SYSTEM->PRCR | PRCR_KEY) | PRC0_MASK);

        /* Enable the trace clock, using 1/4 divisor - gives TRCLK 1/2 ICLK */
        /* As the PLL is configured to 240Mhz for RA6M3 device by FSP (to be able to generate the USB clock) */
        /* but TRCLK max freq = 60Mhz. Changing at runtime works for ITM printf, not ITM trace */
        R_SYSTEM->TRCKCR_b.TRCKEN = TRACE_CLOCK_DISABLE;
        R_SYSTEM->TRCKCR_b.TRCK   = TRCK_4;
        R_SYSTEM->TRCKCR_b.TRCKEN = TRACE_CLOCK_ENABLE;

        /* Restore previous PRC0 setting */
        R_SYSTEM->PRCR = (uint16_t) (((R_SYSTEM->PRCR | PRCR_KEY) & ~PRC0_MASK) | prc0);
#endif

    }
    else if (BSP_WARM_START_POST_C == event) {
		/* C runtime environment and system clocks are setup. */
        fsp_err_t err;
        uint32_t i;

        /* Register the Stack MPU user callback */
        R_BSP_GroupIrqWrite(BSP_GRP_IRQ_MPU_STACK, usr_nmi_hw_stack_callback);

        /* Reset the Ethernet PHY before the Ethernet pins are configured so they are the power on defaults (inputs no pull ups),
         * and don't mess with the default settings of the PHY pin strapping for the PHY address */
        /* Find the pin config for the PHY reset pin and set it */
        for (i = 0; i < g_bsp_pin_cfg.number_of_pins; i++)
        {
            if (ETHER_PHY_RESET_PIN == g_bsp_pin_cfg.p_pin_cfg_data[i].pin)
            {
                err = g_ioport_on_ioport.pinCfg(&g_ioport_ctrl, ETHER_PHY_RESET_PIN, g_bsp_pin_cfg.p_pin_cfg_data[i].pin_cfg);
                if (FSP_SUCCESS != err)
                {
                    /* TODO - some error handling */
                }


                err = g_ioport_on_ioport.pinWrite(&g_ioport_ctrl, ETHER_PHY_RESET_PIN, PHY_RESET_LEVEL);
                if (FSP_SUCCESS != err)
                {
                    /* TODO - some error handling */
                }

                R_BSP_SoftwareDelay(PHY_RESET_ACTIVE_TIMING, BSP_DELAY_UNITS_MILLISECONDS);

                err = g_ioport_on_ioport.pinWrite(&g_ioport_ctrl, ETHER_PHY_RESET_PIN, PHY_ACTIVE_LEVEL);
                if (FSP_SUCCESS != err)
                {
                    /* TODO - some error handling */
                }

                break;
            }
        }

        initialise_monitor_handles();

		/* Configure pins. */
		R_IOPORT_Open(&g_ioport_ctrl, &g_bsp_pin_cfg);
	}
}
