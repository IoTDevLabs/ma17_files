#ifndef I2C_SENSOR_H_
#define I2C_SENSOR_H_

/*
 * function declarations
 */
fsp_err_t init_sensor(void);
void deinit_sensor(void);
fsp_err_t read_sensor_data(float *temp, float *humidity);

#endif /* I2C_SENSOR_H_ */
