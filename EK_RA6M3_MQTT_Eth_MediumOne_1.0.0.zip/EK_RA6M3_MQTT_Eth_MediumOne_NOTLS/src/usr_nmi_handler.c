#include "bsp_api.h"
#include "usr_nmi_handler.h"

void usr_nmi_hw_stack_callback(bsp_grp_irq_t irq)
{
    FSP_PARAMETER_NOT_USED(irq);
	
	uint32_t psp;
	uint32_t msp;
	
	msp = __get_MSP();
	psp = __get_PSP();
	
	if ((R_MPU_SPMON[0].SP->SA > msp) || (R_MPU_SPMON[0].SP->EA < msp))
	{
		__BKPT(0); /* MSP stack outside range. Interrupt/kernel stack overflow. */
	}
	else if ((R_MPU_SPMON[1].SP->SA > psp) || (R_MPU_SPMON[1].SP->EA < psp))
	{
	    __BKPT(0); /* PSP stack outside range. Thread stack overflow. */
	}
	else
	{
	    __BKPT(0); /* Shouldn't get here. */
	}

	
}
