/*
 * usr_credenditials.h
 *
 *  Created on: 2 Jul 2020
 *      Author: jimbo
 */

#ifndef USR_CREDENDITIALS_H_
#define USR_CREDENDITIALS_H_

#define SERVER_CERTIFICATE ""


#define CLIENT_CERTIFICATE ""


#define CLIENT_KEY ""


#endif /* USR_CREDENDITIALS_H_ */
