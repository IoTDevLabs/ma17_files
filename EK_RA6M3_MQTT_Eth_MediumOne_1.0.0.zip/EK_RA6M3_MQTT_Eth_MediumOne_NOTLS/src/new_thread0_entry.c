#include "new_thread0.h"
#include "eui_48.h"

#include "FreeRTOS_IP.h"

#include "iot_logging_task.h"
#include "iot_mqtt.h"
#include "iot_system_init.h"
#include "iot_init.h"

#include "medium_one.h"
#include "mqtt_interface.h"

#include "usr_credenditials.h"

#include "i2c_sensor.h"

fsp_err_t config_littlFs_flash(void);

/* The MAC address array is not declared const as the MAC address will
normally be read from an EEPROM and not hard coded (in real deployed
applications).*/
extern uint8_t g_ether0_mac_address[6];

typedef struct
{
    uint32_t id;
    uint32_t server_ip;
    uint32_t status;
} nwk_param_t;

nwk_param_t g_network;

/* Define the network addressing.  These parameters will be used if either
ipconfigUDE_DHCP is 0 or if ipconfigUSE_DHCP is 1 but DHCP auto configuration
failed. */
/* ipconfigUDE_DHCP is 1 in this project, so a IP address will attempted to be ontained via DHCP */
static const uint8_t ucIPAddress[ 4 ]        = { 192, 168, 0, 200 };
static const uint8_t ucNetMask[ 4 ]          = { 255, 255, 255, 0 };
static const uint8_t ucGatewayAddress[ 4 ]   = { 192, 168, 0, 1 };

static mqtt_cfg_t g_mqtt_cfg     = { 0 };

static mqtt_status_t g_mqtt_status =
{ .mqtt_lib_init_status = !(FSP_SUCCESS), .mqtt_connect_status = !(FSP_SUCCESS), .status = !(FSP_SUCCESS)};

#define LOGGING_TASK_STACK_SIZE         (1 * 1024)
#define LOGGING_TASK_STACK_PRIORITY     (6)
#define LOGGING_TASK_QUEUE_SIZE         (1 * 1024)

/* Address of the DNS server. */
static const uint8_t ucDNSServerAddress[ 4 ] = { 192, 168, 0, 1 };

static char SERVER_CERTIFICATE_PEM[] = SERVER_CERTIFICATE;
static char CLIENT_CERTIFICATE_PEM[] = CLIENT_CERTIFICATE;
static char CLIENT_KEY_PEM[]         = CLIENT_KEY;

/* Medium One MQTT username & password */
#if defined(clientcredentialMQTT_BROKER_USERNAME)
static char CLIENT_USERNAME[] = clientcredentialMQTT_BROKER_USERNAME;
#endif
#if defined(clientcredentialMQTT_BROKER_PASSWORD)
static char CLIENT_PASSWORD[] = clientcredentialMQTT_BROKER_PASSWORD;
#endif

const IotNetworkServerInfo_t serverInfo =
		AWS_IOT_NETWORK_SERVER_INFO_AFR_INITIALIZER;

const IotNetworkCredentials_t afrCredentials =
{ .pAlpnProtos = NULL,
  .maxFragmentLength = 1400,
  .disableSni = true,
  .pRootCa = SERVER_CERTIFICATE_PEM,
  .rootCaSize = sizeof(SERVER_CERTIFICATE_PEM),
  .pClientCert = CLIENT_CERTIFICATE_PEM,
  .clientCertSize = sizeof(CLIENT_CERTIFICATE_PEM),
  .pPrivateKey = CLIENT_KEY_PEM,
  .privateKeySize = sizeof(CLIENT_KEY_PEM),
};

sensor_data_t sensor_data = { 0 };

void new_thread0_entry(void *pvParameters) {
	FSP_PARAMETER_NOT_USED(pvParameters);

    //ProvisioningParams_t params =   { 0 };
    fsp_err_t err = FSP_SUCCESS;
    BaseType_t bt_status =     { 0 };
    int ierr = FSP_SUCCESS;
#if 0  /* NOT USED */
	err = config_littlFs_flash();
	if(FSP_SUCCESS != err)
	{
		printf("** littleFs flash config failed **\r\n");
		__BKPT(0);
	}
#endif
    bt_status = xLoggingTaskInitialize(LOGGING_TASK_STACK_SIZE, LOGGING_TASK_STACK_PRIORITY, LOGGING_TASK_QUEUE_SIZE);
    if (pdPASS != bt_status)
    {
		printf("** xLogging Task Initialize failed **\r\n");
		__BKPT(0);
    }

    /* Initialize I2C sensor */
    if (FSP_SUCCESS != init_sensor()) {
    	printf("** Sensor initialization failed **\r\n");
    	deinit_sensor();
		__BKPT(0);
    }

    ierr = mbedtls_platform_setup (NULL);
    if (FSP_SUCCESS != ierr)
    {
    	printf("** HW SCE Init failed **\r\n");
		__BKPT(0);
    }
#if 0  /* NOT USED */
    err = vAlternateKeyProvisioning (&params);
    if (FSP_SUCCESS != err)
    {
		printf("** Alternate Key Provisioning failed **\r\n");
		__BKPT(0);
    }
#endif
	printf("Starting TCP stack\r\n");

	/* Set the MAC address to a unique value, rather than the default set in the configurator */
	/* OUI */
	g_ether0_mac_address[0] = EUI_48_OCTET_1;
	g_ether0_mac_address[1] = EUI_48_OCTET_2;
	g_ether0_mac_address[2] = EUI_48_OCTET_3;

	/* Device unique part of  EUI-48 */
	g_ether0_mac_address[3] =  ADD_0X (EUI_48_OCTET_4);
	g_ether0_mac_address[4] =  ADD_0X (EUI_48_OCTET_5);
	g_ether0_mac_address[5] =  ADD_0X (EUI_48_OCTET_6);

	bt_status = FreeRTOS_IPInit( ucIPAddress,
					 ucNetMask,
					 ucGatewayAddress,
					 ucDNSServerAddress,
					 g_ether0_mac_address);
	if (pdPASS != bt_status)
	{
		printf("** IP Init failed **\r\n");
		__BKPT(0);
	}

    /* Wait for the network to come up */
    bt_status = xSemaphoreTake( g_network_binary_semaphore, portMAX_DELAY);
    if (pdPASS != bt_status)
    {
		printf("** Network semaphore error **\r\n");
		__BKPT(0);
    }

    bt_status = SYSTEM_Init ();
    if (pdPASS != bt_status)
    {
		printf("** Socket Init failed **\r\n");
		__BKPT(0);
    }

    err = IotSdk_Init ();
    if (pdPASS != err)
    {
		printf("** SDK Init failed **\r\n");
		__BKPT(0);
    }

    g_mqtt_cfg.aws_mqtt_mode = false;
    g_mqtt_cfg.p_identifier = "RA-mqtt-application";
    g_mqtt_cfg.p_nwk_credn_info = (IotNetworkCredentials_t *) NULL; //&afrCredentials;
    g_mqtt_cfg.p_nwk_intf = (IotNetworkInterface_t *) IOT_NETWORK_INTERFACE_AFR;
    g_mqtt_cfg.p_nwk_srvr_info = (IotNetworkServerInfo_t *) &serverInfo;
    g_mqtt_cfg.mqtt_connect_status = false;
    g_mqtt_cfg.mqtt_lib_init_status = false;
#if defined(clientcredentialMQTT_BROKER_USERNAME)
    g_mqtt_cfg.p_mqtt_username = CLIENT_USERNAME;
#endif
#if defined(clientcredentialMQTT_BROKER_PASSWORD)
    g_mqtt_cfg.p_mqtt_password = CLIENT_PASSWORD;
#endif

    if (EXIT_FAILURE == mqtt_init (&g_mqtt_cfg))
    {
		printf("** MQTT Client returned with Error **\r\n");
		__BKPT(0);
    }

    if((true == g_mqtt_cfg.mqtt_connect_status) && (true == g_mqtt_cfg.mqtt_lib_init_status))
    {
		g_network.status = FSP_SUCCESS;
		g_mqtt_status.status = EXIT_SUCCESS;
    }

    printf("Successful MQTT Connection to the endpoint\r\n");
    printf("Device is Ready for Publishing and Subscription of Messages \r\n\r\n");

	/* TODO: add your own code here */

    int result;

	while (1) {

		if (FSP_SUCCESS != read_sensor_data(&sensor_data.temperature, &sensor_data.humidity)) {
			printf("** SENSOR READ FAILED **\r\n");
			sensor_data.temperature = 0.0f;
			sensor_data.humidity = 0.0f;
		} else {
			sensor_data.temperature = (sensor_data.temperature * (9.0f/5.0f)) + 32.0f;  // convert to F
		}

		sensor_data.iteration++;
		sensor_data.timestamp = xTaskGetTickCount();

		result = sendMessage_mo(&sensor_data);
		if (0 != result)
		{
			__BKPT(0);
		}

		vTaskDelay(5000);
	}
}

#if 0  /* NOT USED */
fsp_err_t config_littlFs_flash(void)
{
    fsp_err_t err = FSP_SUCCESS;

    err = RM_LITTLEFS_FLASH_Open(&g_rm_littlefs0_ctrl, &g_rm_littlefs0_cfg);
    if(FSP_SUCCESS != err)
    {
		printf("** littleFs Initialization failed **\r\n");
    }
    else
    {
		err = lfs_format(&g_rm_littlefs0_lfs, &g_rm_littlefs0_lfs_cfg);
		if(FSP_SUCCESS != err)
		{
			printf("** littleFs Flash Format failed **\r\n");
		}
		else
		{
			err = lfs_mount(&g_rm_littlefs0_lfs, &g_rm_littlefs0_lfs_cfg);
			if(FSP_SUCCESS != err)
			{
				printf("** littleFs Mount failed **\r\n");
			}
		}
    }
    return err;
}
#endif
