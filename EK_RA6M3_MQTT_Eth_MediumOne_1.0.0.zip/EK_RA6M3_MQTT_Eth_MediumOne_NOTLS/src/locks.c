#include "new_thread0.h"
#include <malloc.h>


void __malloc_lock (struct _reent *reent);
void __malloc_unlock (struct _reent *reent);

SemaphoreHandle_t xMutex = NULL;


void __malloc_lock(struct _reent *ptr)
{

	if (NULL == xMutex)
	{
		xMutex = xSemaphoreCreateRecursiveMutex();
	}
	 BaseType_t bt_status;
	 bt_status = xSemaphoreTakeRecursive(xMutex, portMAX_DELAY);
	 if (pdTRUE != bt_status)
	{
		__BKPT(0); //need some error handling
	}


}

void __malloc_unlock(struct _reent *ptr)
{

	 BaseType_t bt_status;
	 bt_status = xSemaphoreGiveRecursive(xMutex);
	 if (pdTRUE != bt_status)
	{
		__BKPT(0); //need some error handling
	}
}

