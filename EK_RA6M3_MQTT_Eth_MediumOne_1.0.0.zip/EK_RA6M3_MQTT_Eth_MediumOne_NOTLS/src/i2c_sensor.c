#include "bsp_api.h"
#include "hal_data.h"
#include "i2c_sensor.h"

#define RESET_VALUE             (0x00)

/* SHT code adapted from examples in MikroElectronica/SHT_click repo
 * https://github.com/MikroElektronika/SHT_click/blob/master/library/__sht_driver.c
 */

#define SHT_I2C_ADDR0           0x44    /* set in RA Configuration editor */
#define SHT_I2C_ADDR1           0x25

#define SHT_STR_ENABLE          0x2C    /* clock stretching enabled */
#define SHT_STR_DISABLE         0x24

#define SHT_RPT_HIGH_STR_ENA    0x06
#define SHT_RPT_MEDIUM_STR_ENA  0x0D    /* med repeatability with clock stretching enabled */
#define SHT_RPT_LOW_STR_ENA     0x10

#define SHT_RPT_HIGH_STR_DIS    0x00
#define SHT_RPT_MEDIUM_STR_DIS  0x0B    /* med repeatability with clock stretching disabled */
#define SHT_RPT_LOW_DTR_DIS     0x16

/*
 * Global Variables
 */
/* Reading I2C call back event through i2c_Master callback */
static volatile i2c_master_event_t i2c_event = I2C_MASTER_EVENT_ABORTED;

/*
 * private function declarations
 */
static fsp_err_t validate_i2c_event(void);

/*******************************************************************************************************************//**
 *  @brief       initialize IIC master module and set up SHT sensor
 *  @param[IN]   None
 *  @retval      FSP_SUCCESS                  Upon successful open and start of timer
 *  @retval      Any Other Error code apart from FSP_SUCCESS is  Unsuccessful open or start
 **********************************************************************************************************************/
fsp_err_t init_sensor(void)
{
    fsp_err_t err     = FSP_SUCCESS;
    uint8_t soft_reset_cmd[2]  = { 0x30, 0xA2 };
    uint8_t read_status_cmd[2] = { 0xF3, 0x2D };
    uint8_t status_bytes[3] = { 0, 0, 0 };

#if 1  /* needed if P413 is configured for initial low */
    /* De-assert RST signal to SHT click */
    printf("De-assert SHT reset\r\n");
    R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_13, BSP_IO_LEVEL_HIGH);  // RST on P413
    R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);
#endif

    /* Open IIC master module */
    printf("Open I2C master\r\n");
    err = R_IIC_MASTER_Open(&g_i2c_master_ctrl, &g_i2c_master_cfg);

    /* Check error */
    if (FSP_SUCCESS != err)
    {
        printf("** R_IIC_MASTER_Open API failed **\r\n");
        return err;
    }

#if 1
    /* Soft reset */
    printf("Issue SHT soft reset command\r\n");
    err = R_IIC_MASTER_Write(&g_i2c_master_ctrl, soft_reset_cmd, 2, false);
    if (FSP_SUCCESS != err) {
        printf("** R_IIC_MASTER_Write() failed, soft reset command [err=%d]\r\n", err);
        return err;
    } else {
        err = validate_i2c_event();
        if (FSP_SUCCESS != err) {
            printf("** validate_i2c_event() failed, soft reset command [err=%d]\r\n", err);
            return err;
        }
    R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);
    }
#endif

#if 1
    /* Read status register */
    printf("Send SHT read status register command\r\n");
    err = R_IIC_MASTER_Write(&g_i2c_master_ctrl, read_status_cmd, 2, false);
    if (FSP_SUCCESS != err) {
        printf("** R_IIC_MASTER_Write() failed, read status command [err=%d]\r\n", err);
        return err;
    } else {
        err = validate_i2c_event();
        if (FSP_SUCCESS != err) {
            printf("** validate_i2c_event() failed, read status command [err=%d]\r\n", err);
            return err;
        }
    }

    printf("Read SHT status register bytes\r\n");
    err = R_IIC_MASTER_Read(&g_i2c_master_ctrl, status_bytes, 3, false);
    if (FSP_SUCCESS != err) {
        printf("** R_IIC_MASTER_Read() failed, read status bytes [err=%d]\r\n", err);
        return err;
    } else {
        err = validate_i2c_event();
        if (FSP_SUCCESS != err) {
            printf("** validate_i2c_event() failed, read status bytes [err=%d]\r\n", err);
            return err;
        }
    }

    printf("SHT status bytes: MSB: 0x%02X, LSB: 0x%02X, CRC: 0x%02X\r\n", status_bytes[0], status_bytes[1], status_bytes[2]);  // msb, lsb, crc
#endif

    return err;
}

/*******************************************************************************************************************//**
 *  @brief       DeInitialize IIC master module
 *  @param[IN]   None
 *  @retval      None
 **********************************************************************************************************************/
void deinit_sensor(void)
{
    fsp_err_t err     = FSP_SUCCESS;

    /* close open modules */
    err =  R_IIC_MASTER_Close (&g_i2c_master_ctrl);

    if (FSP_SUCCESS != err)
    {
        printf("** R_IIC_MASTER_Close API failed ** \r\n");
    }
}
fsp_err_t read_sensor_data(float *temp, float *humid)
{
    // Read 6 bytes from SHT sensor, return temp C and humid %

    fsp_err_t err = FSP_SUCCESS;
    uint8_t cmd[2] = { SHT_STR_ENABLE, SHT_RPT_MEDIUM_STR_ENA };  // clock stretching enabled, medium repeatability
    //uint8_t cmd[2] = { SHT_STR_DISABLE, SHT_RPT_MEDIUM_STR_DIS };  // clock stretching disabled, medium repeatability
    uint8_t resp[6];
    float temperature, humidity;

    /* Issue read command */
    err = R_IIC_MASTER_Write(&g_i2c_master_ctrl, &cmd[0], 2, false /*true*/);

    if (FSP_SUCCESS != err)
    {
        printf("** SHT I2C write of read temp command failed, stage 1 [err=%d] **\r\n", err);
        return err;
    }
    else
    {
        err = validate_i2c_event();

        /* Performs read operation only when write event is successful, failure part is handled at next stage*/
        if (FSP_SUCCESS == err)
        {
            /* Delay for conversion to complete */
            R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);

            /* Read measurements */
            err = R_IIC_MASTER_Read(&g_i2c_master_ctrl, resp, 6, false);

            /* handle error */
            if (FSP_SUCCESS != err)
            {
                printf("** SHT I2C read failed, stage 1 [err=%d] **\r\n", err);
                return err;
            }
            else
            {
                err = validate_i2c_event();
                if (FSP_SUCCESS != err)
                {
                    printf("** SHT I2C read failed, stage 2 [err=%d] **\r\n", err);
                    return err;
                }
            }
        }
        else
        {
            printf("** SHT I2C write of read temp command failed, stage 2 [err=%d] **\r\n", err);
            return err;
        }

        /*  Read is successful, process response bytes */

        //printf("** SHT I2C temperature read was successful **\r\n");

        uint16_t raw_temperature;
        uint16_t raw_humidity;

        raw_temperature = (uint16_t)((resp[0] << 8) | resp[1]);
        temperature = (175.0f * ((float)raw_temperature / 65535.0f)) - 45.0f;
        raw_humidity = (uint16_t)((resp[3] << 8) | resp[4]);
        humidity = 100.0f * ((float)raw_humidity / 65535.0f);

        *temp = temperature;
        *humid = humidity;
    }

    return err;
}

/*******************************************************************************************************************//**
 *  @brief      User callback function
 *  @param[in]  p_args
 *  @retval None
 **********************************************************************************************************************/
void i2c_master_callback(i2c_master_callback_args_t *p_args)
{
    if (NULL != p_args)
    {
        /* capture callback event for validating the i2c transfer event*/
        i2c_event = p_args->event;
    }
}

/*******************************************************************************************************************//**
 *  @brief       Validate i2c receive/transmit  based on required write read operation
 *
 *  @param[in]   None
 *
 *  @retval      FSP_SUCCESS                       successful event receiving returns FSP_SUCCESS
 *               FSP_ERR_TRANSFER_ABORTED          Either on timeout elapsed or received callback event is
 *                                                 I2C_MASTER_EVENT_ABORTED
 **********************************************************************************************************************/
static fsp_err_t validate_i2c_event(void)
{
    uint16_t local_time_out = UINT16_MAX;

    /* resetting call back event capture variable */
    i2c_event = RESET_VALUE;

    do
    {
        /* This is to avoid infinite loop */
        --local_time_out;

        if(RESET_VALUE == local_time_out)
        {
            return FSP_ERR_TRANSFER_ABORTED;
        }

    }while(i2c_event == RESET_VALUE);

    if(i2c_event != I2C_MASTER_EVENT_ABORTED)
    {
        i2c_event = RESET_VALUE;  // Make sure this is always Reset before return
        return FSP_SUCCESS;
    }

    i2c_event = RESET_VALUE; // Make sure this is always Reset before return
    return FSP_ERR_TRANSFER_ABORTED;
}
