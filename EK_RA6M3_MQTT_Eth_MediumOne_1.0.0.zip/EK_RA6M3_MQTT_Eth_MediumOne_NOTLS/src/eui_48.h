/*
 * eui_48.h
 *
 *  Created on: 12 Nov 2019
 *      Author: a5094302
 */

#ifndef EUI_48_H_
#define EUI_48_H_

/* REA's OUI: 00:30:55:xx:xx:xx */
#define EUI_48_OCTET_1 0x00 /*OUI 1st octet*/
#define EUI_48_OCTET_2 0x30 /*OUI 2nd octet*/
#define EUI_48_OCTET_3 0x55 /*OUI 3rd octet*/

/* Device unique part of  EUI-48, in HEX without leading 0x, as these parts of the EUI-48 are used for the hostname as well */
#define EUI_48_OCTET_4 03
#define EUI_48_OCTET_5 02
#define EUI_48_OCTET_6 01

#define STRINGIFY(s) # s
#define EXPAND_TO_STRING(x) STRINGIFY(x)

#define ADD_LEADING_0X(a, b) a ## b
#define ADD_0X(a) ADD_LEADING_0X(0x, a)



#endif /* EUI_48_H_ */
