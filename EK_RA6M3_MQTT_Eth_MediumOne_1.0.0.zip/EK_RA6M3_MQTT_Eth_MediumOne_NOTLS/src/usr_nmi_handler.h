/*
 * usr_nmi_handler.h
 *
 *  Created on: 11 Nov 2019
 *      Author: a5094302
 */

#ifndef USR_NMI_HANDLER_H_
#define USR_NMI_HANDLER_H_

void R_BSP_WarmStart(bsp_warm_start_event_t event);
void usr_nmi_hw_stack_callback(bsp_grp_irq_t irq)__attribute__((optimize("-O0")));

#endif /* USR_NMI_HANDLER_H_ */
